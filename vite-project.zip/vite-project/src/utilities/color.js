const bgColor=()=>{
    return "#FDFFF6"
}
const textColor=()=>{
    return "#001140"
}
const whiteColor=()=>{
    return "#F5F5F5"
}
const whiteColort=()=>{
    return "rgba(255,255,255,0.5)"
}
export {bgColor,textColor,whiteColor,whiteColort}