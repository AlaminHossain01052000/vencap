function pf(x) {
    return parseFloat(parseFloat(x).toFixed(2));
  }
  export default pf;
  